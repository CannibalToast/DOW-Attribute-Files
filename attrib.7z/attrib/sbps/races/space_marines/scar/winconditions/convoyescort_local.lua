Localization = 
{
exclusive = false,
victory_condition = true,
always_on = false,
title = "Win/lose: Convoy Escort",
win_message = "You have successfully escorted the convoy!",
lose_message = "You FAILED to escort your convoy to the destination on map!",
description = "Escort a convoy transport to the center of the map to win!"
}
