Localization = 
{
	exclusive		= false,
	victory_condition	= false,
	always_on		= false,
	title			= "Addon: Industrial Cities",
	win_message 		= "",
	lose_message 		= "",
	description		= "Start the game with randomly placed Urban Cities throughout the map. They hold unique researches while captured."
}