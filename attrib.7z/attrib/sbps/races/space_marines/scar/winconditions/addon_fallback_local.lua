Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Fallback Rule",
win_message = "",
lose_message = "",
description = "Morale Broken squads fall back to nearest Strategic Point."
}
