Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Miscellaneous: Hardcore",
win_message = "",
lose_message = "",
description = "All units and structures have decreased health and morale. !Bad to combine this wincondition with Softcore!"
}
