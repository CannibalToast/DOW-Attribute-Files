Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: AI MapDB",
win_message = "",
lose_message = "",
description = "Uses improved pathing checks for enemy units."
}
