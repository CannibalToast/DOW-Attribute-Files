Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Incomes: Titan Wars [UNSTABLE]",
win_message = "",
lose_message = "",
description = "Increases relic resource maximum amount by 100% (1000 default). Decreases titan population costs by half if the player is Orks."
}
