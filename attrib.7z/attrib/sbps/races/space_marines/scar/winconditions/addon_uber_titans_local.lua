Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Uber Relic Units",
win_message = "",
lose_message = "",
description = "Increases the health and morale of all relic units and titans by 200%. Costs and build times are doubled."
}
