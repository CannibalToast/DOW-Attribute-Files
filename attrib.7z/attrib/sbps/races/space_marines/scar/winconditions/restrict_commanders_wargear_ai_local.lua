Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Restriction: Hero Wargear (AI)",
win_message = "",
lose_message = "",
description = "If activated, all Artificial Intelligence commanders of any type are not allowed to purchase hero upgrades."
}
