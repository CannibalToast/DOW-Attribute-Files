Localization = 
{
	exclusive				= false,
	victory_condition	= false,
	always_on			= false,
	title						= "Restriction: Aircraft",
	win_message 		= "",
	lose_message 	= "",
	description			= "Restricts all aircraft types, even transports and relic/titan unit aircrafts. Wincondition is mostly to avoid aircraft being 'stuck'.",
}