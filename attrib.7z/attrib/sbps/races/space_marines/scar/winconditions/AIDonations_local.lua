Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Softcore",
win_message = "",
lose_message = "",
description = "All units and structures have increased health and morale. !Bad to combine this wincondition with Hardcore!"
}
