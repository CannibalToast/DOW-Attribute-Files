Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Rabbit Speed",
win_message = "",
lose_message = "",
description = "The time it takes to produce or build anything takes 0.5x as long."
}
