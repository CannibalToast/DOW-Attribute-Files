Localization = 
{
	exclusive				= false,
	victory_condition	= true,
	always_on			= false,
	title						= "Win/lose: Economic Victory",
	win_message 		= "$60103",
	lose_message 	= "$60203",
	description			= "$60303"
}