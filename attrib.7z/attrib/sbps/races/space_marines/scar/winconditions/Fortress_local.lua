Localization = 
{
	exclusive				= false,
	victory_condition	= true,
	always_on			= false,
	title						= "Win/lose: Civilian Slaughter",
	win_message 		= "Congratulations! You killed a bunch of defenseless people.",
	lose_message 	= "You lossed all of your Civilians!",
	description			= "Assassinate the other player's civilian units to win!"
}