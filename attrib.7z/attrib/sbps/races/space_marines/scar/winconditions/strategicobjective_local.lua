Localization = 
{
	exclusive				= false,
	victory_condition	= true,
	always_on			= false,
	title						= "Win/lose: Take and Hold",
	win_message 		= "$60102",
	lose_message 	= "$60202",
	description			= "$60302"
}