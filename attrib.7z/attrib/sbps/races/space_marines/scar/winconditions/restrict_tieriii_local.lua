Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Restriction: Tier III",
win_message = "",
lose_message = "",
description = "If activated, all races are unable to advance to Tier III."
}
