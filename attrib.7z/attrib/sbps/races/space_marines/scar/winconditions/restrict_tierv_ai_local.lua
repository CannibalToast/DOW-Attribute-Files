Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "AI Restriction: Game Enders (AI)",
win_message = "",
lose_message = "",
description = "(Not working) If activated, all artificial intelligence races are unable to build super structures or unleash superweapons. This does not affect players."
}
