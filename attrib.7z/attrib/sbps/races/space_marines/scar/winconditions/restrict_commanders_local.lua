Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Restriction: Commanders",
win_message = "",
lose_message = "",
description = "If activated, all commanders of any type are restricted."
}
