Localization = 
{
	exclusive				= false,
	victory_condition	= false,
	always_on			= false,
	title				= "Addon: Nuclear War",
	win_message 		= "",
	lose_message 		= "",
	description			= "All super structures (end game structures) will be able to unleash superweapons 2x faster. (10 minutes default reduced to 5 minutes)",
}