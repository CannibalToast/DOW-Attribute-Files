Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Incomes: Scarce Resources [UNSTABLE]",
win_message = "",
lose_message = "",
description = "Takes away over half of resources on game start, decreases resource rates by 50%."
}
