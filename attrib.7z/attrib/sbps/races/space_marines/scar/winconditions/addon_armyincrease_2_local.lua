Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Army Cap +20 [UNSTABLE]",
win_message = "",
lose_message = "",
description = "Can be stacked. Increases the maximum squad/support cap limit by 20. Default is 30."
}
