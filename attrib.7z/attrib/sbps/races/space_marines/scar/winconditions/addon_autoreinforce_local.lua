Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Miscellaneous: Automatic Reinforce [UNSTABLE]",
win_message = "",
lose_message = "",
description = "Non Multiplayer compatible. All squads will reinforce automatically when not engaged in combat. WARNING! This win condition bugs the game when you save a game and reload it."
}
