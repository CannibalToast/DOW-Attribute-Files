Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Miscellaneous: Fast Abilities [UNSTABLE]",
win_message = "",
lose_message = "",
description = "Abilities recharge at a faster rate"
}
