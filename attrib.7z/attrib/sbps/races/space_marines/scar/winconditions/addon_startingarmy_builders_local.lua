Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Starting Army: Builders",
win_message = "",
lose_message = "",
description = "If activated, all races start the game with a builder unit. By default, no builders are spawned."
}
