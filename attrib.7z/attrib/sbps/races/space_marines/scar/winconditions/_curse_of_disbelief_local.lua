Localization = 
{
exclusive = true,
victory_condition = true,
always_on = false,
title = "THE CURSE OF DISBELIEF",
win_message = "You survived the Zombie Apocalypse!",
lose_message = "You didn't survive the Zombie Apocalypse!",
description = "Zombies! Survive for a period of time on the map of your choice. Each day you survive increases in difficulty."
}
