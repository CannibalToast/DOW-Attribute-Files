Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "TestAddon: AI Dummies",
win_message = "",
lose_message = "",
description = "Disables the artificial intelligence. Used for mostly modders and testing."
}
