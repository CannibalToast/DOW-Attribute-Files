Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Incomes: Titan Wars Extreme [UNSTABLE]",
win_message = "",
lose_message = "",
description = "Increases relic resource maximum amount by 1000% (1000 default). Decreases titan population costs by 100% if the player is Orks."
}
