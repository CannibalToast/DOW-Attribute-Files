Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Uber Commanders",
win_message = "",
lose_message = "",
description = "Increases the health and morale of all commanders by 200%. Costs of commanders are doubled."
}
