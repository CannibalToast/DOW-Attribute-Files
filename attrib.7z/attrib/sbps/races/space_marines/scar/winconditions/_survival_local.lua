Localization = 
{
exclusive = true,
victory_condition = true,
always_on = false,
title = "Ultimate Apocalypse: Survival",
win_message = "Mission Success!",
lose_message = "Mission Failed!",
description = "Play Survival anywhere and on any map! Note: The bigger the map, the better survival plays."
}
