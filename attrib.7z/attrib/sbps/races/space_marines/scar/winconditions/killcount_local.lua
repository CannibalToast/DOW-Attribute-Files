Localization = 
{
exclusive = false,
victory_condition = true,
always_on = false,
title = "Win/lose: Kill Ratio",
win_message	= "Your victory of blood shed shal feed the BLOOD OF THE BLOOD GOD!",
lose_message = "This failure, the lack of bloodshed will be FOREVER REMEMBERED!",
description = "Kill a randomly assigned number of enemies to win!"
}
