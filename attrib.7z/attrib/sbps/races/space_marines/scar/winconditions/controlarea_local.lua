Localization = 
{
	exclusive				= false,
	victory_condition	= true,
	always_on			= false,
	title						= "Win/lose: Control Area",
	win_message 		= "$60108",
	lose_message 	= "$60208",
	description			= "$60308"
}