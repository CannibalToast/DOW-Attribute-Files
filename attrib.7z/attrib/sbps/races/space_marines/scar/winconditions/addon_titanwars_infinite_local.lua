Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Titan Wars Infinite",
win_message = "",
lose_message = "",
description = "Increases relic resource maximum amount by 99,999% along with its rate. Ork titans cost no pop cap."
}
