Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Army Cap +10 [UNSTABLE]",
win_message = "",
lose_message = "",
description = "Can be stacked. Increases the maximum squad/support cap limit by 10. Default is 30."
}
