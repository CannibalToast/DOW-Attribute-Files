Localization = 
{
	exclusive				= false,
	victory_condition	= false,
	always_on			= false,
	title						= "Miscellaneous: Tips and Tricks",
	win_message 		= "",
	lose_message 	= "",
	description			= "Throughout the game, Lord Cylarne will teach you some Ultimate Apocalypse mod tips.",
}