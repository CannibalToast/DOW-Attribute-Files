Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Scarce Resource Rates",
win_message = "",
lose_message = "",
description = "Decreases resource rates by 50%. If you like squad management / extremely long games, this wincondition is for you!"
}
