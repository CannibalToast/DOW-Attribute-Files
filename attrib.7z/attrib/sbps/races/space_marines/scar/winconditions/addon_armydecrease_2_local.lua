Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Army Cap / 3",
win_message = "",
lose_message = "",
description = "Can be stacked. Decreases the maximum army cap by 66%, no matter how many times stacked."
}
