Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Miscellaneous: Disable Fog",
win_message = "",
lose_message = "",
description = "The entire map gets revealed."
}
