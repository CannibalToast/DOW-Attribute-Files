Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Restriction: Titans",
win_message = "",
lose_message = "",
description = "If activated, all titans are restricted."
}
