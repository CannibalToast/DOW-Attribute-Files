Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "AI Army Cap / 2",
win_message = "",
lose_message = "",
description = "Can be stacked. Decreases the maximum army cap by half for the AI only, no matter how many times stacked. This may help in performance against AI."
}
