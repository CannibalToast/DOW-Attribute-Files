Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Speed: Turtle",
win_message = "",
lose_message = "",
description = "The time it takes to produce or build anything takes 1.5x as long."
}
