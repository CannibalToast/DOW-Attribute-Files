Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Incomes: Rich Resource Rates [UNSTABLE]",
win_message = "",
lose_message = "",
description = "Gives all players 2x more income rates. Warning! This might make the AI a bit more aggressive and crazy. Use with caution."
}
