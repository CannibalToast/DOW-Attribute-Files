Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Incomes: Rich Resources [UNSTABLE]",
win_message = "",
lose_message = "",
description = "Gives all players 10x more resources on game start. Warning! This might make the AI a bit more aggressive and crazy. Use with caution."
}
