Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Uber Structures",
win_message = "",
lose_message = "",
description = "Increases the health of all structures by 200%."
}
