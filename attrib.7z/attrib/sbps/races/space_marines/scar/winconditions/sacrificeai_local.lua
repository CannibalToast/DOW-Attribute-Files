Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Medium Core",
win_message = "",
lose_message = "",
description = "All units and structures have decreased health and morale less so than on hardcore (50%)."
}
