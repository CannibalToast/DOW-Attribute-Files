Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Restriction: Fortress Defenses",
win_message = "",
lose_message = "",
description = "WARNING! This wincondition will break the AI. Restricts base defenses such as turrets, advanced turrets, and walls from all players."
}
