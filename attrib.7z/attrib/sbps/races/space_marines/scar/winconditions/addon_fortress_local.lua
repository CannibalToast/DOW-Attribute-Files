Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Fortress Defenses",
win_message = "",
lose_message = "",
description = "All defensive walls, tank traps, and turrets are 2x more durable."
}
