Localization = 
{
exclusive = false,
victory_condition = false,
always_on = true,
title = "Apocalypse Rules",
win_message = "",
lose_message = "",
description = "Apocalypse Rules remains as default. Adds a special event to the entire game, allowing super structures to be revealed in single player and AI Wargear + other AI tactics."
}
