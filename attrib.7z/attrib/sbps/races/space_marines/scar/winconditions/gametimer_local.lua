Localization = 
{
	exclusive				= false,
	victory_condition	= false,
	always_on			= false,
	title						= "Game Timer",
	win_message 		= "$60310",
	lose_message 	= "$60310",
	description			= "$60310"
}
