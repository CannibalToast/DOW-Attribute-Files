Localization = 
{
	exclusive				= true,
	victory_condition	= true,
	always_on			= false,
	title				= "Win/lose: Random Objectives",
	win_message 		= "You win!",
	lose_message 		= "You lose!",
	description			= "Assigns random objectives to each player. Each player will have to achieve victory via assigned winconditions."
}