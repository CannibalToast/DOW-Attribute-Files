Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Miscellaneous: Fallback Rule [UNSTABLE]",
win_message = "",
lose_message = "",
description = "Morale Broken squads fall back to nearest Strategic Point."
}
