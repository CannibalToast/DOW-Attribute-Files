Localization = 
{
exclusive = false,
victory_condition = true,
always_on = false,
title = "Win/lose: Extermination",
win_message	= "You have exterminated the enemy!",
lose_message = "You have been exterminated by the enemy.",
description = "Destroy the enemy entirely. All buildings and units must be annihilated for victory."
}
