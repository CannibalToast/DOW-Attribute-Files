Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Dev: Instant",
win_message = "",
lose_message = "",
description = "All units, structures, research, and addons are produced/built instantly."
}
