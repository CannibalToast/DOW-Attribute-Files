Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Speed Snail",
win_message = "",
lose_message = "",
description = "The time it takes to produce or build anything takes 2x as long."
}
