Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Restriction: Tier IV",
win_message = "",
lose_message = "",
description = "If activated, all races are unable to advance to Tier IV."
}
