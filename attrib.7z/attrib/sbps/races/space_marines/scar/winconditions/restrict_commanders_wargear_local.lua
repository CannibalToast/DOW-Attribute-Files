Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Restriction: Hero Wargear",
win_message = "",
lose_message = "",
description = "If activated, all commanders of any type are not allowed to purchase hero upgrades."
}
