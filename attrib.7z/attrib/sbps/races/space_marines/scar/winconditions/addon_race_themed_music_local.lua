Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Race-Specific Themes",
win_message = "",
lose_message = "",
description = "The Music Playlist for each player is that of the race he chooses."
}
