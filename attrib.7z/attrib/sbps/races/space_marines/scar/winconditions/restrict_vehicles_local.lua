Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Restriction: Vehicles",
win_message = "",
lose_message = "",
description = "Disables the production of vehicles. Relic unit vehicles are an exception, and you must restrict relic units for that."
}
