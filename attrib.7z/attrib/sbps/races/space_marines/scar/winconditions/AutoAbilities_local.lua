Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Miscellaneous: Auto Abilities [UNSTABLE]",
win_message = "",
lose_message = "",
description = "Squads with special abilities will automatically use them"
}
