Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Heroes",
win_message = "",
lose_message = "",
description = "Squads get battle experience and gain in power. !Not compatible in multiplayer!"
}
