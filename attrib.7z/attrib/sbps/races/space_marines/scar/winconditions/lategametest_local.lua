Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "LATE GAME TEST",
win_message = "",
lose_message = "",
description = "For late game testing"
}
