Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Army Cap / 3 (AI)",
win_message = "",
lose_message = "",
description = "Can be stacked. Decreases the maximum army cap by 66%, for the AI only. This may help in performance against AI."
}
