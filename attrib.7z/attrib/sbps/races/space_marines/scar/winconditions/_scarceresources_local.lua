Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Scarce Resources",
win_message = "",
lose_message = "",
description = "Takes away from players and AI over half of their own resources on game start."
}
