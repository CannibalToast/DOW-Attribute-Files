Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Restriction: Game Enders",
win_message = "",
lose_message = "",
description = "If activated, all races are unable to unleash game ending technologies."
}
