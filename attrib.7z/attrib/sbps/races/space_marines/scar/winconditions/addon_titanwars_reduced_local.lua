Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Incomes: Titan Wars Reduced",
win_message = "",
lose_message = "",
description = "Decreases relic resource maximum amount by 50% (1000 default). Increases titan population costs by 50% if the player is Orks."
}
