Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "TestAddon: Sandbox + Map Reveal",
win_message = "",
lose_message = "",
description = "WARNING! Does not work after saving your game! Sets up sandbox mode. Allows the player to switch between CPUs, but does not disable AI. Reveals the map."
}
