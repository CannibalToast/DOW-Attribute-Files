Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Army Cap +100",
win_message = "",
lose_message = "",
description = "Can be stacked. Increases the maximum squad/support cap limit by 100. Default is 30. WARNING! This may cause extreme lag with lots of units on screen."
}
