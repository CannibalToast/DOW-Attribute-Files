Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "TestAddon: Crazy Insane",
win_message = "",
lose_message = "",
description = "All units, structures, research, and addons are produced/built instantly."
}
