Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Legio Titanicus (Unstable)",
win_message = "",
lose_message = "",
description = "Allows Legio Titans created by Moshpit and increases relic resources that will allow even Imperator Titans."
}
