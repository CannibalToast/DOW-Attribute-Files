Localization = 
{
	exclusive				= false,
	victory_condition	= true,
	always_on			= false,
	title						= "Win/lose: Sudden Death",
	win_message 		= "$60105",
	lose_message 	= "$60205",
	description			= "$60305"
}