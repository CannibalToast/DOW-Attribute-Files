Localization = 
{
	exclusive				= false,
	victory_condition	= true,
	always_on			= false,
	title						= "Win/lose: Assassinate",
	win_message 		= "$60104",
	lose_message 	= "$60204",
	description			= "$60304"
}