Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "AI Restriction: All Relic Units (AI)",
win_message = "",
lose_message = "",
description = "If activated, all relic units and titans are restricted for the artificial intelligence. This will not affect players."
}
