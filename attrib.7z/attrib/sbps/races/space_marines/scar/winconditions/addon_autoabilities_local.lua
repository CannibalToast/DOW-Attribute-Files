Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: Auto Abilities",
win_message = "",
lose_message = "",
description = "Squads with special abilities will automatically use them"
}
