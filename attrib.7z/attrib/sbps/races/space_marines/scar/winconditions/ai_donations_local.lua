Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Addon: AI Donations",
win_message = "",
lose_message = "",
description = "WARNING! Not multiplayer usable! Allows the AI to exchange resources with players or AI."
}
