Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "AI Addon: Extremecore",
win_message = "",
lose_message = "",
description = "All units and structures have decreased health and morale even more so than on hardcore."
}
