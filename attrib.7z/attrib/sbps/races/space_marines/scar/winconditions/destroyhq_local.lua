Localization = 
{
	exclusive				= false,
	victory_condition	= true,
	always_on			= false,
	title						= "Win/lose: Destroy HQ (Unstable)",
	win_message 		= "$60106",
	lose_message 	= "$60206",
	description			= "$60306"
}