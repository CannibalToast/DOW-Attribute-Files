Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Incomes: Rich Resources [UNSTABLE]",
win_message = "",
lose_message = "",
description = "10x more resources on game start, 2x more income rates. Warning! Use with caution."
}
