Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Army Cap +40 ",
win_message = "",
lose_message = "",
description = "Can be stacked. Increases the maximum squad/support cap limit by 40. Default is 30. WARNING! This may cause some lag with lots of units on screen."
}
